package com.cg;

import java.util.Locale;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class MainApp {

	public static void main(String[] args) {

		// basic
		/*
		 * BeanFactory beanFactory=new XmlBeanFactory(new FileSystemResource("Spring.xml"));
		 * 
		 * Triangle triangle=(Triangle) beanFactory.getBean("triangle");
		 */

		/*AbstractApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
		context.registerShutdownHook();*/
		/*Triangle triangle = context.getBean("triangle", Triangle.class);

		triangle.draw();
*/
		
		 /*Circle circle=context.getBean("circle", Circle.class);
		 circle.draw();
		 */
		
		/*
		Employee emp=(Employee) context.getBean("employee");
		System.out.println(emp.getDob());
		*/
		/*Circle1 cir=(Circle1) context.getBean("cir");
		cir.draw();
		System.out.println("Done succesfully");*/
		
		
		/*AbstractApplicationContext context =new AnnotationConfigApplicationContext(MyConfig.class);
		context.registerShutdownHook();
		
		Customer cust= (Customer) context.getBean("customer");
		Customer cust1= (Customer) context.getBean("cust");
		
		System.out.println(cust);
		System.out.println(cust1);
		
		Circle1 c=(Circle1) context.getBean("circle1");
		c.draw();
		
	*/
		
		ApplicationContext context=new ClassPathXmlApplicationContext("Spring.xml");
		/*String msg=context.getMessage("greeting", null, "Default Greeting", null);
								//		key		parameter	Default-message	location
		System.out.println(msg);*/
		
		/*Circle1 circle1=(Circle1) context.getBean("circle1");
		circle1.draw();*/
		
		MessageSource s=(MessageSource) context.getBean("messageSource");
		Locale locale=new Locale("in","TG");
		String msg=s.getMessage("welcome.message", null, "Default Message", locale);
		System.out.println(msg);
		
		/*ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
        MessageSource bean2 = (MessageSource) context.getBean("messageSource");
        Locale locale = new Locale("IN", "tamil");
        String message = bean2.getMessage("welcome.message", null, "default Message", locale);
        System.out.println(message);*/      
	}
}
