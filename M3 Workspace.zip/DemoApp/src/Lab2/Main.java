package Lab2;

import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();

		int choice = 0;
		do {
			System.out.println("1.Insert Book Details");
			System.out.println("2.All Books");
			System.out.println("3.Search Books By Author Name");
			System.out.println("4.Search Books By Price");
			System.out.println("5.Search Author By BookId");
			System.out.println("Enter Choice: ");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				Author1 au = new Author1();
				sc.nextLine();
				System.out.println("Enter Author Name");
				au.setName(sc.nextLine());
				System.out.println("Enter number of books");
				int n = sc.nextInt();
				for (int i = 1; i <= n; i++) {
					Book book = new Book();
					sc.nextLine();
					System.out.println("Enter the title of book" + i);
					book.setTitle(sc.nextLine());
					System.out.println("Enter the price of book" + i);
					book.setPrice(sc.nextFloat());
					book.setAuthor1(au);
					au.getBooks().add(book);
					em.getTransaction().begin();
					em.persist(au);
					em.getTransaction().commit();
				}
				break;
			case 2:
				TypedQuery<Book> query2 = em.createQuery("from Book", Book.class);
				List<Book>book3=query2.getResultList();
				for (Book book : book3) {
					System.out.println(book);
				}
				break;
			case 3:
				System.out.println("Enter Author Name");
				String name = sc.next();
				TypedQuery<Author1> query = em.createQuery("from Author1 where name=:n", Author1.class);
				query.setParameter("n", name);
				Author1 a1 = query.getSingleResult();
				System.out.println(a1.getBooks());
				break;
			case 4:
				System.out.println("Enter Minimum Price and Maximum Price");
				float minPrice = sc.nextFloat();
				float maxPrice = sc.nextFloat();
				TypedQuery<Book> query1 = em.createQuery("from Book where price>=:p1 and price<=:p2 ", Book.class);
				query1.setParameter("p1", minPrice);
				query1.setParameter("p2", maxPrice);
				List<Book> book2 = query1.getResultList();
				System.out.println(book2);
				break;

			case 5:
				System.out.println("Enter Book Id");
				int id = sc.nextInt();
				TypedQuery<Book> query3 = em.createQuery("from Book where isbn=:i", Book.class);
				query3.setParameter("i", id);
				Book book =query3.getSingleResult();
				System.out.println("===============");
				System.out.println(book.getAuthor1().getName());
				System.out.println("===============");
				break;

			case 6:
				break;

			}
		} while (choice != 6);
	}

}
