package Lab1_Author;

import java.sql.SQLException;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class main {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		Scanner sc= new Scanner(System.in);
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		
		EntityManager em=factory.createEntityManager();
		Author au=new Author();
		
		
		
		int choice = 0;
		do {
			System.out.println("1.Insert");
			System.out.println("2.Update");
			System.out.println("3.Delete");
			System.out.println("Enter Choice: ");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				sc.nextLine();
				au.getAuthorId();
				System.out.println("Enter First Name");
				au.setFirstName(sc.nextLine());
				System.out.println("Enter Middle Name");
				au.setMiddleName(sc.nextLine());
				System.out.println("Enter Last Name");
				au.setLastName(sc.nextLine());
				System.out.println("Enter Phone Number");
				au.setPhoneNo(sc.nextFloat());

				em.getTransaction().begin();
				em.persist(au);
				em.getTransaction().commit();
				System.out.println(au);
				break;
			case 2:
				em.getTransaction().begin();
				System.out.println("Enter the Id");
				au = em.find(Author.class, sc.nextInt());
				sc.nextLine();
				System.out.println("Enter First Name");
				au.setFirstName(sc.nextLine());
				System.out.println("Enter Middle Name");
				au.setMiddleName(sc.nextLine());
				System.out.println("Enter Last Name");
				au.setLastName(sc.nextLine());
				System.out.println("Enter Phone Number");
				au.setPhoneNo(sc.nextFloat());
				em.getTransaction().commit();
				System.out.println("After Commit");
				System.out.println(au);
				break;
			case 3:
				sc.nextLine();
				em.getTransaction().begin();
				System.out.println("Enter the Id");
				au = em.find(Author.class, sc.nextInt());
				em.remove(au);
				em.getTransaction().commit();
				System.out.println("Author Deleted");
				System.out.println(au);
				break;

			case 4:
				break;

			}
		} while (choice != 4);
	
	}

}
