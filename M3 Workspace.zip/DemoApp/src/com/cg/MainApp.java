package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp {

	public static void main(String[] args) {

		/*
		 * Scanner sc= new Scanner (System.in); Employee emp=new Employee();
		 * System.out.println("Enter Id");
		 * emp.setId(Integer.parseInt(sc.nextLine()));
		 * System.out.println("Enter Name"); emp.setName(sc.nextLine());
		 * System.out.println("Enter Gender"); emp.setGender(sc.nextLine());
		 * System.out.println("Enter Age");
		 * emp.setAge(Integer.parseInt(sc.nextLine()));
		 * System.out.println("Enter Salary");
		 * emp.setSalary(Float.parseFloat(sc.nextLine()));
		 * Class.forName("oracle.jdbc.driver.OracleDriver"); String
		 * url="jdbc:oracle:thin:@localhost:1521/xe"; Connection connection =
		 * DriverManager.getConnection(url, "INVENTORY1", "INVENTORY1"); String
		 * SQL="INSERT INTO EMPLOYEEDE VALUES(?,?,?,?,?)"; PreparedStatement
		 * pstat= connection.prepareStatement(SQL); pstat.setInt(1,
		 * emp.getId()); pstat.setString(2, emp.getName()); pstat.setString(3,
		 * emp.getGender()); pstat.setInt(4, emp.getAge()); pstat.setFloat(5,
		 * emp.getSalary()); pstat.executeUpdate(); pstat.close();
		 */

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

		EntityManager em = factory.createEntityManager();
		
		// finding or reading employee

		// Employee emp=em.find(Employee.class,102);
		// System.out.println(emp);

		// update transaction

		// em.getTransaction().begin();
		// Employee emp=em.find(Employee.class,102);
		// System.out.println(emp);
		// emp.setSalary(77000);
		// emp.setAge(21);
		// em.getTransaction().commit();
		// System.out.println("After Commit");
		// System.out.println(emp);

		// INSERT EMPLOYEE IN TO THE TABLE

		/*
		 * Employee emp=new Employee(102,"Akhil", "Male",22,45000);
		 * em.getTransaction().begin(); em.persist(emp);
		 * em.getTransaction().commit(); System.out.println("Data Saved");
		 */

		// REMOVING AN EMPLOYEE

		/*
		 * em.getTransaction().begin(); Employee
		 * emp=em.find(Employee.class,101); System.out.println(emp);
		 * em.remove(emp); em.getTransaction().commit();
		 * System.out.println("After Commit"); System.out.println(emp);
		 */

		/*
		 * em.getTransaction().begin(); Employee e=em.find(Employee.class,103);
		 * Employee e1=em.find(Employee.class,104); System.out.println(e);
		 * em.detach(e); //only one object is detached e.setAge(35);
		 * em.merge(e); //to merge the detached object e1.setAge(64);
		 * em.clear(); //to detach all objects em.getTransaction().commit();
		 * System.out.println("After Commit");
		 */

		Employee emp = new Employee();
		emp.setName("Mark");
		emp.setGender("Male");
		emp.setAge(35);
		emp.setSalary(59000);
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		System.out.println("After Commit");

	}
}
