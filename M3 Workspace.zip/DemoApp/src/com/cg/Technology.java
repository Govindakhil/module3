package com.cg;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Technology {
	@Id
	@GeneratedValue
	private int technologyId;
	private String technologyName;
	/*
	 * @OneToOne private Faculty faculty;
	 */

	/*
	 * @ManyToOne private Faculty faculty;
	 * 
	 * public Faculty getFaculty() { return faculty; }
	 * 
	 * public void setFaculty(Faculty faculty) { this.faculty = faculty; }
	 */
	@ManyToMany
	private List<Faculty> Faculties = new ArrayList<>();

	public List<Faculty> getFaculties() {
		return Faculties;
	}

	public void setFaculties(List<Faculty> faculties) {
		Faculties = faculties;
	}

	public int getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(int technologyId) {
		this.technologyId = technologyId;
	}

	public String getTechnologyName() {
		return technologyName;
	}

	public void setTechnologyName(String technologyName) {
		this.technologyName = technologyName;
	}

	@Override
	public String toString() {
		return "Technology [technologyId=" + technologyId + ", technologyName=" + technologyName + ", Faculties="
				+ Faculties + "]";
	}

}
