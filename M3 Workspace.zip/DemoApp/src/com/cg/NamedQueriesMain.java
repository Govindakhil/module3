package com.cg;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class NamedQueriesMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		TypedQuery<Employee> query = em.createNamedQuery("getAllEmployees",Employee.class);
		
		List<Employee> employees=query.getResultList();
		for (Employee employee : employees) {
			System.out.println(employee);
		}
		System.out.println("==========================================");
		query=em.createNamedQuery("getEmployeeByGender",Employee.class);
		query.setParameter("gen", "Male");
		List<Employee> employeesGen=query.getResultList();
		for (Employee employee : employeesGen) {
			System.out.println(employee);
		}
	}

}
