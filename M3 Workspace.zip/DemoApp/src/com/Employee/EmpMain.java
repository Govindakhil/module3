package com.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Lab1_Author.main;

public class EmpMain {
	
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		
		Employee1 emp3 =new Employee1();
		emp3.setName("Tanmay");
		TemporaryEmployee temp=new TemporaryEmployee();
		temp.setName("shilpa");
		temp.setDailyWage(500);
		PermanentEmployee pemp=new PermanentEmployee();
		pemp.setName("Shivani");
		pemp.setAnnualSalary(56000);
		em.getTransaction().begin();
		em.persist(emp3);
		em.persist(temp);
		em.persist(pemp);
		em.getTransaction().commit();
		System.out.println("Done");
	}

}
