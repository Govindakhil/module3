package com.cg.dao;

import com.cg.beans.Account;

public class DaoImpl implements Dao {

	@Override
	public void createAccount(Account account) {
		
		
	}

	@Override
	public void deposit(Integer amount, Integer accountNo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw(Integer amount, Integer accountNo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double checkBalance(Integer accountNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void fundtransfer(Integer accountNo1, Integer accountNo2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void transactionList(Integer accountNo) {
		// TODO Auto-generated method stub
		
	}

}
